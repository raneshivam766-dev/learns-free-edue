# Learns Free — Website Starter

Mobile-friendly static starter website for Maharashtra SSC, HSC (Science, Commerce, Arts) and MHT-CET PCM/PCB.

## Included
- `index.html`: responsive website with class/stream/subject navigation
- Sample chapter lists
- Demo quizzes with instant score and explanations
- English/Marathi interface toggle
- Board-question, notes and PDF sections ready for content

## Publish on GitHub Pages
1. Open your `learns-free` repository.
2. Choose **Add file → Upload files**.
3. Upload `index.html` and commit to `main`.
4. Open **Settings → Pages**.
5. Set Source to **Deploy from a branch**, Branch to `main`, Folder to `/(root)`, then Save.

Website URL: https://raneshivam766-dev.github.io/learns-free/

## Important
This is a functional starter template, not a complete textbook content library. It includes sample chapter lists and demo quiz questions only. Add reviewed, accurate notes, verified board questions, answer keys and authorized PDFs before publishing them as official or previous-year material. Do not upload copyrighted books or papers unless you have permission.

## Add PDFs
Create a `pdfs` folder in the repository, upload your PDF, then link it from the relevant chapter using a relative path such as `pdfs/physics-chapter-1.pdf`.

## Expand content
Edit the `subjects`, `chapters` and `bank` JavaScript objects near the bottom of `index.html`.
